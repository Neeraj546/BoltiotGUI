try:
	import sqlite3
except:
	print("No module named '_sqlite3'")
	
class queryDB:
	def __init__(self,db):
		self.conn = sqlite3.connect(db)
		self.cur = self.conn.cursor()
		self.cur.execute("CREATE TABLE IF NOT EXISTS queries (Command text, executable text, output text)")
		self.conn.commit()
	def insert(self, Command, executable, output):
		self.cur.execute("INSERT INTO queries VALUES (?, ?, ?)",(Command, executable, output))
		self.conn.commit()
	def delete(self, Command):
		self.cur.execute("DELETE FROM queries WHERE Command = ?",(Command,))
		self.conn.commit()
	def fetchquires(self):
		self.cur.execute("SELECT * FROM queries")
		rows = self.cur.fetchall()
		return rows
	def getcommand(self,Command):
		self.cur.execute("SELECT * FROM queries WHERE Command = ?",(Command,))
		rows = self.cur.fetchall()
		return rows
	def update(self, Command, pre, executable, output):
		self.cur.execute("UPDATE queries SET Command = ?, executable = ?, output = ? WHERE Command = ?", (Command, executable, output, pre))
		self.conn.commit()
	def __del__(self):
		self.conn.close()
db = queryDB('queries.db')
