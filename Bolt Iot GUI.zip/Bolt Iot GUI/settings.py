import os
import pyttsx3
from boltiot import Bolt
from importlib import reload
from boltconn import BoltconnDB
from db import queryDB
from tkinter import *

#Definations
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0])
rate = engine.getProperty('rate')
engine.setProperty('rate', 170)
myname = "Jarvis"
conndb = BoltconnDB('connection.db')
querydb = queryDB('queries.db')

#speak Function
def speak(msg):
	engine.say("{}".format(msg))
	engine.runAndWait()
	engine.stop()

#connect Bolt Device
def connect_bolt():
	count = connpage()
	if(device_id.get()=="" or Bolt_api.get()==""):
		speak("Please Enter valid device id and A P I Key")
	elif(count >= 1):
		speak("A device is already connected please disconnect it and try again")
	else:
		conndb.connectdev(device_id.get(),Bolt_api.get(),1)
		device_entry.delete(0,END)
		api_entry.delete(0,END)
		speak("Connected")
	conndev()
			
			
#disconnect Bolt Device
def disconnect_bolt():
	count = connpage()
	if(count >= 1):
		conndb.disconnectdev(1)
		speak("disconnected")
	else:
		speak("No Device is connected")
	conndev()
	
#Add
def add_command():
	row_count = 0
	for row in querydb.getcommand(command.get().lower()):
		if(row[row_count]==command.get().lower()):
			available = True
		row_count+=1
	if(command.get().lower()=="" or query.get()=="" or output.get()==""):
		speak("All Fields are required")
	elif((row_count > 0)and(available)):
		speak("Query is Already available try updating it")
	else:
		querydb.insert(command.get().lower(),query.get(),output.get())
		speak("Query added Successfully")
	listloader()
	clear_command()
	
#loader
def listloader():
	querylist.delete(0,END)
	for row in querydb.fetchquires():
		querylist.insert(END,row)
		
#query select
def select_query(event):
	global selected
	index = querylist.curselection()[0]
	selected = querylist.get(index)
	clear_command()
	command_entry.insert(END,selected[0])
	query_entry.insert(END,selected[1])
	output_entry.insert(END,selected[2])

#update
def update_command():
	if(command.get().lower()=="" or query.get()=="" or output.get()==""):
		speak("All Fields are required")
	else:
		row_count = 0
		available=False
		for row in querydb.getcommand(selected[0]):
			if(row[row_count]==selected[0]):
				available=True
				cmdtemp = row[row_count]
				break
			row_count+=1
		if(available):
			querydb.update(command.get().lower(), selected[0], query.get(), output.get())
			speak(selected[0]+" query updated Successfully")
		else:
			speak("please Select Query from list")
		listloader()
		clear_command()

#clear
def clear_command():
	command_entry.delete(0,END)
	query_entry.delete(0,END)
	output_entry.delete(0,END)

#delete
def delete_command():
	if(command.get().lower()==""):
		speak("Command field is required for deleting query")
	else:
		row_count = 0
		available=False
		for row in querydb.getcommand(command.get().lower()):
			if(row[row_count]==command.get().lower()):
				available=True
				break
			row_count+=1
		if(available):
			querydb.delete(command.get().lower())
			speak(command.get().lower()+" query deleted Successfully")
		else:
			speak("Entered Query Is not available in data base")
		listloader()
		clear_command()
			
#conn page
def connpage():
	row_count = 0
	for row in conndb.connchck(1):
		row_count+=1
	return(row_count)
	
#connected Device
def conndev():
	row_count = 0
	for row in conndb.getdevicenane(1):
		row_count+=1
	devlist.delete(0,END)
	if(row_count >= 1):
		devlist.insert(0,row[0])
	else:
		devlist.insert(0,"None")
	devlist.see(0)

#create window
app = Tk()

#app title
app.title("Bolt IOT With GUI and Voice Assisted")

#app dimensions
app.geometry("900x550")

#Header

header_label = Label(app, text='Connection', font=('bold', 15), pady=6, width="30")
header_label.grid(row=0,column=0,columnspan=4)
	
#device ID
	
device_id = StringVar()
device_label = Label(app, text='Enter Your Bolt Device ID', font=('bold', 10), pady=10, width="30",height="3")
device_label.grid(row=1,column=0)
device_entry = Entry(app, textvariable=device_id)
device_entry.grid(row=1,column=1)
	
#Bolt API
	
Bolt_api = StringVar()
api_label = Label(app, text='Enter Your Bolt API Key', font=('bold', 10), pady=10, width="30",height="3")
api_label.grid(row=1,column=2)
api_entry = Entry(app, textvariable=Bolt_api)
api_entry.grid(row=1,column=3)

#connect Bolt Device
connect_btn = Button(app, text="Connect Bolt Device", width="30", command=connect_bolt, border=1, bg="white")
connect_btn.grid(row=2,column=0,columnspan=2)

#disconnect Bolt Device
disconnect_btn = Button(app, text="disconnect", width="30", command=disconnect_bolt, border=1, bg="white")
disconnect_btn.grid(row=2,column=2,columnspan=2)

#device name
conn_label = Label(app, text='Connected Device : ', font=('bold', 10), pady=10, width="30",height="3")
conn_label.grid(row=3,column=0,columnspan=2)
devlist = Listbox(app, width="20", height="1")
devlist.grid(row=3,column=1,columnspan=2)
	
#connected device
conndev()

#Header

header_label = Label(app, text='Commands', font=('bold', 15), pady=2, width="30")
header_label.grid(row=4,column=0,columnspan=4)

#Command
	
command = StringVar()
command_label = Label(app, text='Enter Your Command ', font=('bold', 10), pady=2, width="30",height="3")
command_label.grid(row=5,column=0)
command_entry = Entry(app, textvariable=command)
command_entry.grid(row=5,column=1)
	
#Executable
	
query = StringVar()
query_label = Label(app, text='Enter Executable Code', font=('bold', 10), pady=2, width="30",height="3")
query_label.grid(row=5,column=2)
query_entry = Entry(app, textvariable=query)
query_entry.grid(row=5,column=3)

#output

output = StringVar()
output_label = Label(app, text='Enter output', font=('bold', 10), pady=2, width="30",height="3")
output_label.grid(row=6,column=0)
output_entry = Entry(app, textvariable=output)
output_entry.grid(row=6,column=1)

#Add
add_btn = Button(app, text="Add", width="20", command=add_command, border=1, bg="white")
add_btn.grid(row=7,column=0)

#Update
update_btn = Button(app, text="Update", width="20", command=update_command, border=1, bg="white")
update_btn.grid(row=7,column=1)

#Clear
clear_btn = Button(app, text="Clear", width="20", command=clear_command, border=1, bg="white")
clear_btn.grid(row=7,column=2)

#Delete
delete_btn = Button(app, text="Delete", width="20", command=delete_command, border=1, bg="white")
delete_btn.grid(row=7,column=3)

#Query List
querylist = Listbox(app, width="90", height="8")
querylist.grid(row=8,column=0,columnspan=4,rowspan=2)

#bind select
querylist.bind('<<ListboxSelect>>',select_query)

#list loader
listloader()

#start program
app.mainloop()
