import pyttsx3
from boltiot import Bolt

#definations
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0])
rate = engine.getProperty('rate')
engine.setProperty('rate', 170)

#Creating Class
class extras:
	#text to speech
	def speak(msg):
		engine.say("{}".format(msg))
		engine.runAndWait()
		engine.stop()
		
	#Bolt Connect
	def Connect_Bolt(Device_id, Api_key):
		mybolt = Bolt(Api_key, Device_id)
		return mybolt
