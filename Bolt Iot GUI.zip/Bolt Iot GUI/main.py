from boltconn import BoltconnDB
from db import queryDB
from tkinter import *
import speech_recognition as sr
import os
import pyttsx3
from urllib.request import urlopen
from boltiot import Bolt

#Definations
r = sr.Recognizer()
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0])
rate = engine.getProperty('rate')
engine.setProperty('rate', 170)
myname = "Jarvis"
conndb = BoltconnDB('connection.db')
querydb = queryDB('queries.db')

#speak Function
def speak(msg):
	engine.say("{}".format(msg))
	engine.runAndWait()
	engine.stop()

#speech recognition
def listenme():
	with sr.Microphone() as source:
		audio = r.adjust_for_ambient_noise(source)
		audio = r.listen(source)
	try:
		urlopen('https://www.google.com', timeout=1)
		print(r.recognize_google(audio))
		try:
			recognizedvoice = str(r.recognize_google(audio))
			output_entry.delete(0,END)
			output_entry.insert(END,recognizedvoice)
			Run_Command(recognizedvoice)
		except:
			speak("Couldn't Hear!")
	except:
		speak("Did not Connected to Internet")
		
#customize Settings
def Custom_settings():
	os.system('python3 settings.py')
	devname()
	
#Run Command 
def Run_Command(recognizedvoice):
	count = 0
	for i in querydb.getcommand(recognizedvoice.lower()):
		count += 1
		if(i[0] == recognizedvoice.lower()):
			break
	if(count>0):
		if recognizedvoice.lower() in i[0]:
			row_count = 0
			for row in conndb.getdevicenane(1):
				row_count+=1
			if(row_count >= 1):
				exe_file = open('execute.py','w')
				exe_file.write("from impdata import extras\n\n")
				temp = "extras.Connect_Bolt('" + row[0] + "','" + row[1] + "')." + i[1] + "\n\n"
				exe_file.write(temp)
				exe_file.write("extras.speak('" + i[2] + "')")
				exe_file.close()
				os.system('python3 execute.py')
			else:
				speak("No device is connected")

#Check Internet Connection
def is_internet():
	try:
		urlopen('https://www.google.com', timeout=1)
		sample = Label(app, text='Active', fg="Green", font=('bold', 10), pady=10, width="30",height="3")
		sample.grid(row=0,column=3)
		speak("Connected to Internet")
	except:
		sample = Label(app, text='Inactive', fg="red", font=('bold', 10), pady=10, width="30",height="3")
		sample.grid(row=0,column=3)
		speak("Did not Connected to Internet")
		
#device name
def devname():
	row_count = 0
	for row in conndb.getdevicenane(1):
		row_count+=1
	if(row_count >= 1):
		conn = "Connected Device : " + row[0]
	else:
		conn = "Connected Device : None"
		speak("No Device Connected")
	
	dev = Label(app, text=conn, font=('bold', 10), pady=10, width="30",height="3")
	dev.grid(row=0,column=0)

#create window
app = Tk()

#app title
app.title("Bolt IOT With GUI and Voice Assisted")

#app icon
#app.iconbitmap('main.xpm')

#app dimensions
app.geometry("900x550")

#Connected Device
devname()
Run_Command("turn on lights")

#Internet Connection
is_internet()
sample = Label(app, text='Internet Connection : ', font=('bold', 10), pady=10, width="30",height="3")
sample.grid(row=0,column=2)

#output
sample = Label(app, text='Command : ', font=('bold', 10), pady=10, width="30",height="3")
sample.grid(row=4,column=0)
output_txt = StringVar()
output_entry = Entry(app, textvariable=output_txt, width="25")
output_entry.grid(row=4,column=1)

#Network Refresh
network_btn = Button(app, text="Refresh Network", width="30", command=is_internet,pady=6, border=1, bg="white")
network_btn.grid(row=4,column=2,columnspan=2)

#Listen btn
listen_btn = Button(app, text="Listen", width="50", command=listenme,pady=10, border=1, bg="white")
listen_btn.grid(row=7,column=0,columnspan=2)

#Customize btn
custom_btn = Button(app, text="Customize Settings", width="50", command=Custom_settings,pady=10, border=1, bg="white")
custom_btn.grid(row=8,column=0,columnspan=2)

#start program
app.mainloop()
