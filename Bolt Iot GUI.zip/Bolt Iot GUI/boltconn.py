try:
	import sqlite3
except:
	print("No module named '_sqlite3'")
	
class BoltconnDB:
	def __init__(self,db):
		self.conn = sqlite3.connect(db)
		self.cur = self.conn.cursor()
		self.cur.execute("CREATE TABLE IF NOT EXISTS boltconn (Deviceid text, Apikey text, connected INTEGER)")
		self.conn.commit()
	def connectdev(self, Deviceid, Apikey, connected):
		self.cur.execute("INSERT INTO boltconn VALUES (?, ?, ?)",(Deviceid, Apikey, connected))
		self.conn.commit()
	def disconnectdev(self, connected):
		self.cur.execute("DELETE FROM boltconn WHERE connected = ?",(connected,))
		self.conn.commit()
	def connchck(self,connected):
		self.cur.execute("SELECT * FROM boltconn WHERE connected = ?",(connected,))
		rows = self.cur.fetchall()
		return rows
	def getdevicenane(self,connected):
		self.cur.execute("SELECT * FROM boltconn WHERE connected = ?",(connected,))
		rows = self.cur.fetchall()
		return rows
	def __del__(self):
		self.conn.close()
db = BoltconnDB('connection.db')
